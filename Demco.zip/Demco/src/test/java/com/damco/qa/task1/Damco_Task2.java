package com.damco.qa.task1;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Damco_Task2 {

	@Test
    public void testcase() throws InterruptedException, AWTException
    {
		WebDriver driver = new ChromeDriver();
     driver.get("https://mail.aol.com/");
     driver.manage().window().maximize();
     driver.findElement(By.xpath("//a[@class='login']")).click();
     driver.findElement(By.id("login-username")).sendKeys("kapil.kumar90@aol.com");
     driver.findElement(By.id("login-signin")).click();
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
     driver.findElement(By.id("login-passwd")).sendKeys("Anish@1234@");
     driver.findElement(By.id("login-signin")).click();
     WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
     WebElement composeBtn=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@role='button']")));
     Actions actions = new Actions(driver);
     actions.moveToElement(composeBtn).click().build().perform();
     driver.findElement(By.xpath("(//input[@role='combobox'])[2]")).sendKeys("kapil.kumar90@aol.com");
     driver.findElement(By.xpath("//input[@placeholder='Subject']")).sendKeys("Demco");
     driver.findElement(By.xpath("//div[@role='textbox']")).sendKeys("Line one \nLine two \nLine three");
     WebElement browseButton = driver.findElement(By.xpath("//button[@type='button' and @title='Attach files']"));
     browseButton.click();	
     Robot robot = new Robot();
     String filePath = "C:\\Users\\user\\Desktop\\api.jpg";
     StringSelection selection = new StringSelection(filePath);
     Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
     robot.keyPress(KeyEvent.VK_CONTROL);
     robot.keyPress(KeyEvent.VK_V);
     robot.keyRelease(KeyEvent.VK_V);
     robot.keyRelease(KeyEvent.VK_CONTROL);
     robot.keyPress(KeyEvent.VK_ENTER);
     robot.keyRelease(KeyEvent.VK_ENTER);
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
     driver.findElement(By.xpath("//button[@type='button' and @title='Send this email']")).click();
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
     driver.findElement(By.xpath("//li[@style='padding: 0px;']/div[@data-test-folder-container='Inbox']")).click();
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
     driver.findElement(By.xpath("//div[@class='D_F o_h ab_C H_6D6F a_3vhr3 em_qk ej_0']")).click();
     String expectedEmail="kapil.kumar90@aol.com";
     String actualEmail=driver.findElement(By.xpath("//span[@class='C4_Z29WjXl']")).getText().toString();
     Assert.assertEquals(expectedEmail,actualEmail);
     String expectedSubject="Demco";
     String actualSubject=driver.findElement(By.xpath("//span[@data-test-id='message-group-subject-text']")).getText().toString();
	    Assert.assertEquals(expectedSubject, actualSubject);
	    String expectedBody="Line one \nLine two \nLine three";
	    String actualBody=driver.findElement(By.xpath("(//div[@class='jb_0 X_6MGW N_6Fd5'])[1]")).getText().toString();
	    Assert.assertEquals(expectedBody,actualBody);
	}

}
