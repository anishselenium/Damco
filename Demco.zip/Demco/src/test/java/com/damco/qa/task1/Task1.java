package com.damco.qa.task1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Task1 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.makemytrip.com/flights/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//label[@for='fromCity']")).click();
		WebElement from=driver.findElement(By.xpath("//div[@role='combobox']/input[@type='text']"));
		from.clear();
		from.sendKeys("Delhi");
		driver.findElement(By.xpath("//label[@for='toCity']")).click();
		WebElement to=driver.findElement(By.xpath("//div[@role='combobox']/input[@type='text']"));
		to.clear();
		to.sendKeys("Mumbai");
		to.sendKeys(Keys.ARROW_DOWN);
		to.sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("//div[@class='DayPicker-Day DayPicker-Day--today']")).click();
        driver.findElement(By.xpath("//a[@class='primaryBtn font24 latoBold widgetSearchBtn ']")).click();
        WebDriverWait wait =new WebDriverWait(driver,Duration.ofSeconds(10));
        WebElement ok=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='button buttonSecondry buttonBig fontSize12 relative']")));
        ok.click();
	     driver.findElement(By.xpath("//span[contains(text(),'Departure')]")).click();
	     driver.findElement(By.xpath("(//span[contains(text(),'Price')])[1]")).click();
	     String price=driver.findElement(By.xpath("(//div[@class='textRight flexOne']/div[@class='blackText fontSize18 blackFont white-space-no-wrap'])[2]")).getText().toString();
	     String name=driver.findElement(By.xpath("(//div[@class='makeFlex align-items-center gap-x-10 airline-info-wrapper'])[2]")).getText().toString();
	     System.out.println("Second Lowest Price ="+price);
	     System.out.println("Second Lowest Name ="+name);
	     driver.findElement(By.xpath("//span[contains(text(),'Departure')]")).click();
	}

}
